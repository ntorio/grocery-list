const Grocery = require("../models/groceries.model");

const createNewGrocery = (req, res) => {
    Grocery.create(req.body)
    .then((newGrocery) => {
        res.json({ newGrocery });
    })
    .catch((err) => {
        res.status(400).json({ err });
    });
};

const getAllGroceries = (req, res) => {
    Grocery.find()
    .then((allGroceries) => {
        res.json(allGroceries);
    })
    .catch((err) => {
        res.status(400).json({ err });
    });
};

const getOneGrocery = (req, res) => {
    Grocery.findOne({ _id: req.params.id })
        .then((queriedGrocery) => {
        res.json(queriedGrocery);
    })
    .catch((err) => {
        res.status(400).json({ err });
    });
};

const updateGrocery = (req, res) => {
    Grocery.findOneAndUpdate({ _id: req.params.id }, req.body, {
        new: true,
        runValidators: true,
    })
    .then((updatedGrocery) => {
        res.json({ updatedGrocery });
    })
    .catch((err) => {
        res.status(400).json({ err });
    });
};

const deleteExistingUser = (req, res) => {
    Grocery.deleteOne({ _id: req.params.id })
    .then((deletedResponse) => {
        res.json({ deletedResponse });
    })
    .catch((err) => {
        res.status(400).json({ err });
    });
};

module.exports = {
    createNewGrocery,
    getOneGrocery,
    getAllGroceries,
    updateGrocery,
    deleteExistingUser,
};