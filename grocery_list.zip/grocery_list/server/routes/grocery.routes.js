const groceryController = require("../controllers/grocery.controller");

module.exports = (app) => {
    app.post("/api/grocery", groceryController.createNewGrocery);
    app.get("/api/grocery", groceryController.getAllGroceries);
    app.get("/api/grocery/:id", groceryController.getOneGrocery);
    app.put("/api/grocery/:id", groceryController.updateGrocery);
    app.delete("/api/grocery/:id", groceryController.deleteExistingUser);
};