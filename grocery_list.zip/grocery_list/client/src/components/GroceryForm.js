import axios from "axios";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const GroceryForm = () => {
    const [name, setName] = useState("");
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();
    const handleSubmit = (e) => {
        e.preventDefault();
    axios
        .post("http://localhost:8000/api/grocery", { name })
        .then((response) => {
            console.log(response);
            navigate("/");
        })
        .catch((err) => {
            console.log(err.response.data.err.errors);
            setErrors(err.response.data.err.errors);
        });
    };
    return (
        <div className="container col-12 d-flex align-items-center justify-content-center">
        <div className="row">
            <div className="col-12">
            <Link to="/">See List</Link>
            
            <form onSubmit={handleSubmit}>
                <div className="form-group mt-3">
                <label htmlFor="name"><h5 className="text-success fw-bold">ITEM:</h5></label>
                <input
                    type="text"
                    className="form-control mt-1"
                    onChange={(e) => setName(e.target.value)}
                    value={name}
                />
                {errors.name ? <p>{errors.name.message}</p> : null}
            </div>
            <button className="btn btn-primary fw-bold mt-3" type="submit">ADD</button>
            </form>
            </div>
        </div>
    </div>
    );
};

export default GroceryForm;