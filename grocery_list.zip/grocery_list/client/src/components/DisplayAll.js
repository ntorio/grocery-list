import { useEffect, useState } from "react";

import axios from "axios";
import "../App.css";
import { Link } from "react-router-dom";
const DisplayAll = () => {
    const [allGroceries, setAllGroceries] = useState([]);
    useEffect(() => {
    axios
        .get("http://localhost:8000/api/grocery")
        .then((response) => {
        console.log(response.data);
        setAllGroceries(response.data);
        })
        .catch((err) => {
            console.log(err.response);
        });
    }, []);

    const handleDeleteGrocery = (idFromBelow) => {
    axios
        .delete(`http://localhost:8000/api/grocery/${idFromBelow}`)
        .then((response) => {
            console.log("success deleting grocery");
            console.log(response);
            const filteredGroceries = allGroceries.filter((grocery) => {
                return grocery._id !== idFromBelow;
        });
        setAllGroceries(filteredGroceries);
        })
        .catch((err) => {
            console.log("error deleting grocery", err.response);
        });
    };
    return (
    <div className="container d-flex align-items-center justify-content-center">
        <div className="row">
        <div className="col-12">
            <Link to="/new">Add an item</Link>
            <p className="purple-text"></p>
            <table className="table">
            <thead>
                <tr>
                <th scope="col"><h5 className="text-success fw-bold">ITEMS:</h5></th>
                <th scope="col"></th>
                </tr>
            </thead>
            <tbody>
                {allGroceries.map((grocery, index) => {
                return (
                    <tr key={grocery._id}>
                    <td><h5>{grocery.name}</h5></td>
                    <td>
                        <Link to={`/edit/${grocery._id}`}>
                        <button className="btn btn-primary">Edit</button>
                        </Link>

                        <button
                        onClick={() => handleDeleteGrocery(grocery._id)}
                        className="btn btn-danger">Delete</button>
                    </td>
                    </tr>
                );
                })}
            </tbody>
            </table>
        </div>
        </div>
    </div>
    );
};

export default DisplayAll;