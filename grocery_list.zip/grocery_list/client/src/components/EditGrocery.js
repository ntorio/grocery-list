import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

const EditGrocery = (props) => {
    const { id } = useParams();
    const [groceryName, setGroceryName] = useState("");
    const [errors, setErrors] = useState({});
    const [groceryNotFoundError, setGroceryNotFoundError] = useState("");
    console.log(id);
    useEffect(() => {
    axios
        .get(`http://localhost:8000/api/grocery/${id}`)
        .then((response) => {
        console.log(response.data);
        setGroceryName(response.data.name);
        })
        .catch((err) => {
        console.log(err.response);
        setGroceryNotFoundError(`Grocery not found using that ID`);
        });
    }, []);

    const submitHandler = (e) => {
    e.preventDefault();

    axios
        .put(`http://localhost:8000/api/grocery/${id}`, { name: groceryName })
        .then((response) => {
        console.log(response);
        })
        .catch((err) => {
        console.log(err.response.data.err.errors);
        setErrors(err.response.data.err.errors);
        });
    };
    return (
        
    <form onSubmit={submitHandler}>
        {groceryNotFoundError ? (
        <h2>
            {groceryNotFoundError} <Link to="/new">Click here to add grocery item</Link>
        </h2>
        ) : null}
        <Link to="/">See Updated List</Link>
        <div className="form-group d-flex align-items-center justify-content-center">
        <label htmlFor="name"><h5 className="text-success fw-bold p-1 mt-3">ITEM:</h5></label>
        <input
            type="text"
            id="name"
            value={groceryName}
            onChange={(e) => setGroceryName(e.target.value)}
        />
        {errors.name ? <p>{errors.name.message}</p> : null}
        </div>
        <button type="submit" className="btn btn-primary fw-bold mt-3">Save Changes</button>
    </form>
    );
};

export default EditGrocery;