import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import DisplayAll from "./components/DisplayAll";
import GroceryForm from "./components/GroceryForm";
import EditGrocery from "./components/EditGrocery";

function App() {
  return (
    <div className="mb-10">
    <div class="App">
      <h1 className="p-3 mb-2 bg-success text-white fw-bold">GROCERY LIST</h1>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<DisplayAll />} />
          <Route path="/new" element={<GroceryForm />} />
          <Route path="/edit/:id" element={<EditGrocery />} />
        </Routes>
      </BrowserRouter>
    </div>
    </div>
  );
}

export default App;